<div class="footer">
            
            <div>
                <strong>Copyright @</strong> Cosmetic Shop &copy; <?php echo date("Y"); ?>
            </div>
        </div>