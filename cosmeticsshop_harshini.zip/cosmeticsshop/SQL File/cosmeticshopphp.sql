-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2021 at 07:36 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cosmeticshopphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(11) NOT NULL,
  `AdminName` varchar(45) DEFAULT NULL,
  `UserName` varchar(45) DEFAULT NULL,
  `MobileNumber` bigint(11) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'admin', 'admin', 9229465037, 'admin@gmail.com', 'admin', '2020-08-23 10:30:34');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `ID` int(5) NOT NULL,
  `CategoryName` varchar(120) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`ID`, `CategoryName`, `CreationDate`) VALUES
(10, 'MAKEUP', '2021-03-08 13:35:59'),
(11, 'SKIN', '2021-03-08 13:36:33'),
(12, 'HAIR', '2021-03-08 13:36:52'),
(13, 'APPLIANCES', '2021-03-08 13:37:09'),
(14, 'PERSONAL CARE', '2021-03-08 13:38:46'),
(15, 'NATURAL', '2021-03-08 13:40:21'),
(16, 'HEALTH & WELLNESS', '2021-03-08 13:40:47');

-- --------------------------------------------------------

--
-- Table structure for table `tblorderaddresses`
--

CREATE TABLE `tblorderaddresses` (
  `ID` int(11) NOT NULL,
  `UserId` char(100) DEFAULT NULL,
  `Ordernumber` char(100) DEFAULT NULL,
  `Flatnobuldngno` varchar(255) DEFAULT NULL,
  `StreetName` varchar(255) DEFAULT NULL,
  `Area` varchar(255) DEFAULT NULL,
  `Landmark` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `OrderTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `OrderFinalStatus` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorderaddresses`
--

INSERT INTO `tblorderaddresses` (`ID`, `UserId`, `Ordernumber`, `Flatnobuldngno`, `StreetName`, `Area`, `Landmark`, `City`, `OrderTime`, `OrderFinalStatus`) VALUES
(4, '1', '918824618', '305', 'C Sector', 'Indrapuri', 'YCT Academy', 'Bhopal', '2021-03-08 18:13:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--

CREATE TABLE `tblorders` (
  `ID` int(11) NOT NULL,
  `UserId` char(10) DEFAULT NULL,
  `ProductId` char(10) DEFAULT NULL,
  `IsOrderPlaced` int(11) DEFAULT NULL,
  `OrderNumber` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorders`
--

INSERT INTO `tblorders` (`ID`, `UserId`, `ProductId`, `IsOrderPlaced`, `OrderNumber`) VALUES
(11, '1', '71', 1, '918824618');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `ID` int(10) NOT NULL,
  `CategoryName` varchar(120) DEFAULT NULL,
  `ItemName` varchar(200) DEFAULT NULL,
  `ItemPrice` varchar(120) DEFAULT NULL,
  `ItemDes` varchar(1000) DEFAULT NULL,
  `Image` varchar(200) DEFAULT NULL,
  `ItemQty` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`ID`, `CategoryName`, `ItemName`, `ItemPrice`, `ItemDes`, `Image`, `ItemQty`) VALUES
(64, 'HAIR', 'Aveda Cherry Almond Softening Shampoo', '350', 'Soft , not silicon , 98% naturally derived', '4a76ffa73846e45d4b630d5bf6d6b999.jpg', '100 ml'),
(65, 'HAIR', 'Dove Intense Damage Repair Hair Mask', '473', 'The secret to fixing damaged hair? Let Dove tell you.', '48a9763ca6492fa5fc6b6ea22e5ab748.jpg', '300 ml'),
(66, 'APPLIANCES', 'Havells SC5070 Facial Cleanser - Pink ', '8596', 'Havells SC5070 Facial Cleanser is designed to deeply cleanse and exfoliate your skin.', '42864b5a8af4936e5d122de7aaef5704.jpg', '8 pieces'),
(67, 'MAKEUP', 'Kay Beauty Hydrating Foundation - 105Y Light', '1200', 'Nothing against lipsticks and eyeshadows, but itâ€™s really a foundation thatâ€™s the backbone of any makeup look.', 'cba781e1d5fc3cc1276a51d35f321d6b.jpg', '1'),
(68, 'SKIN', 'Kiehls Midnight Recovery Concentrate', '2100', 'Replenishes overnight for younger looking skin by morning', '8151c319e9bd9037a820b0413eb484aa.jpg', '1'),
(69, 'HAIR', 'L Oreal Paris Dream Lengths Conditioner', '167', 'Strengthens hair and reduces the appearance of split ends', 'bec7f3b363cfd342ee824071691434ac.jpg', '192.5ml'),
(70, 'MAKEUP', 'L Oreal Paris Rouge Signature Matte Liquid Lipstick - 116', '553', 'Apply starting in the center of your upper lip. Work from the center to outer edges of your lips, following the contour of your mouth.', '92f3f41ec3169ded372f69814ce95ec1.jpg', '1'),
(71, 'MAKEUP', 'Lakme Absolute Blur Perfect Makeup Primer - Mini', '200', 'Blur perfect makeup primer , A perfect base for a perfect makeup look.', '1d10ec754e81e8ecfb4d075ef5afb659.jpg', '1'),
(72, 'MAKEUP', 'Lakme Absolute Infinity Eye Shadow Palette', '746', 'Using the sponge applicator apply the eyeshadow. Create different looks by smudging with the applicator or use your fingers. Mix 2 or more shades to create new looks.', '2e7d956c7a9fd458557cffb8b0a490b7.jpg', '1'),
(73, 'MAKEUP', 'Lakme Eyeconic Kajal Twin Pack - Deep Black', '288', 'Perfect for everyday use, the Lakme Eyeconic Kajal is available in 4 gorgeous shades.', '6032cd80e00da437ccb8a63a9267e0dc.jpg', '0.35 g'),
(74, 'APPLIANCES', 'Le Marbelle Jade Roller Face Massager', '1199', 'A jade roller is ancient Chinese tool is the perfect solution to going no Botox on your skin.', '66a1ccad37e61a1ef68b8990137ddbcc.jpg', '1'),
(75, 'SKIN', 'Mario Badescu Drying Lotion', '1600', 'This is the original, award-winning on-the-spot solution. Renowned for its ability to help dry up surface blemishes overnight', 'fb77ac2c05a79669034ddd32444debdb.jpg', '1'),
(76, 'NATURAL', 'Nykaa Naturals Gua Sha - Rose Quartz', '1999', 'This precious stone was passed down through the ages to lift, sculpt and tighten every facial muscle.', '4576dde5df17486ff4d79f4d263a83b7.jpg', '1'),
(77, 'SKIN', 'Nykaa Naturals Tea Tree & Neem Purifying Face Wash', '104', 'Nykaa Naturals Face Wash is a gentle cleanser that refines your skin.', 'a4d126b8576e66d2a84d6b636b560566.jpg', '100 ml'),
(78, 'HEALTH & WELLNESS', 'Oziva Plant Based Collagen Builder', '899', 'OZiva Plant Based Collagen Builder is made from over 21 real, nutritious, plant-based whole foods with ingredients chosen to help support the bodys own collagen production.', '15236e717fe9a2c47bb40a425b2c0d65.jpg', '250 g'),
(79, 'HAIR', 'Philips Heated Straightening Brush', '3495', 'Reveal naturally straight and shiny hair in just 5 minutes. Philips Heated Brush with ThermoProtect technology BHH880/10 features a triple bristle design with keratin infused ceramic coating.                                                 	', 'b59f371e6d72160ac6e71b06afc1ee1d.jpg', '1'),
(80, 'HAIR', 'Philips Selfie Straightener (HP8302/06)', '1295', 'Straighten and style your hair with this easy to use Philips HP8302/00 Selfie Straightener.                                                 	', '9c5e0c061f832367b492c2f6ec622d0a.jpg', '1'),
(81, 'SKIN', 'PIXI Glow Tonic', '1400', 'Pixi Glow Tonic is highly concentrated, invigorating facial toner that deeply cleans pores by sweeping away excess oil and impurities.                                                 	', 'fb77ac2c05a79669034ddd32444debdb.jpg', '150 ml'),
(82, 'PERSONAL CARE', 'Sirona First Period Box Kit', '1499', 'Sirona has put together the First Period Kit to help young girls understand all about periods and changes in their bodies. It has safest period solutions and literature to guide them through their growth journey.', '8057bed1334d983b11f75b87a8288bc1.jpg', '1 Box'),
(83, 'HEALTH & WELLNESS', 'St.Botanica Apple Cider Vinegar', '249', 'Naturally fermented with delicious Himalayan apples, St.Botanica Apple Cider Vinegar is 100 per cent pure and has the goodness of mother of vinegar, that lends it a cloudy look, but is an affirmation of high quality unprocessed vinegar.                                   	', '8a92455be93b0c48a35ff1bf213f0dd6.jpg', '500 ml'),
(84, 'HAIR', 'Tresemme Keratin Smooth Shampoo', '60', 'The secret ingredient formulated with keratin and argan oil', '118c41def3b0f47014afba431a27cfe9.jpg', '85 ml'),
(85, 'APPLIANCES', 'Veet Sensitive Touch Electric Trimmer Expert', '1999', 'Gentleness and precision for your delicate body parts.', '87a03aa50b49c91cd22b3bcbd6f59be6.jpg', '1'),
(86, 'APPLIANCES', 'VEGA Blooming 1000 Air VHDH-05 Hair Dryer', '899', 'Style your hair the way you want with Vega Hair Dryer- Blooming Hair Dryer. You can carry you style in your bag, wherever you go.                                                 	', '2bc23675d334573ca994656a0229ca5a.jpg', '1'),
(87, 'SKIN', 'WOW Skin Science Aloe Vera Gel', '299', 'WOW Skin Science Aloe Vera Gel is 99% pure Aloe Vera, hygienically extracted & carefully packaged, to retain its natural healing & rejuvenating benefits.                                                 	', 'be1fe06518e0c358acfedd24f93ea8b3.jpg', '100 ml');

-- --------------------------------------------------------

--
-- Table structure for table `tblproducttracking`
--

CREATE TABLE `tblproducttracking` (
  `ID` int(10) NOT NULL,
  `OrderId` char(50) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `status` char(50) DEFAULT NULL,
  `StatusDate` timestamp NULL DEFAULT current_timestamp(),
  `OrderCanclledByUser` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `ID` int(10) NOT NULL,
  `FirstName` varchar(45) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(11) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`ID`, `FirstName`, `LastName`, `Email`, `MobileNumber`, `Password`, `RegDate`) VALUES
(1, 'Pankaj', 'Panjwani', 'pankajpanjwani42@gmail.com', 8602768216, 'pankaj', '2020-08-24 05:59:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblorderaddresses`
--
ALTER TABLE `tblorderaddresses`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserId` (`UserId`,`Ordernumber`);

--
-- Indexes for table `tblorders`
--
ALTER TABLE `tblorders`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserId` (`UserId`,`ProductId`,`OrderNumber`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblproducttracking`
--
ALTER TABLE `tblproducttracking`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblorderaddresses`
--
ALTER TABLE `tblorderaddresses`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblorders`
--
ALTER TABLE `tblorders`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `tblproducttracking`
--
ALTER TABLE `tblproducttracking`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
